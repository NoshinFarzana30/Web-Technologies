<?php

require_once('user-info-model.php');

function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function jsonResponse($success, $message) {
    header('Content-Type: application/json');
    echo json_encode(['success' => $success, 'message' => $message]);
  
}

$id = $_COOKIE['id'];
$row = userInfo($id); // Corrected function name

if (isset($_POST['submit'])) {
    $prevpassword = sanitize($_POST['prevpassword']);
    $password = sanitize($_POST['password']);
    $cpassword = sanitize($_POST['cpassword']);

    if (empty($prevpassword) || empty($password) || empty($cpassword)) {
        jsonResponse(false, 'All fields must be filled.');
    }

    if ($prevpassword != $row['Password']) {
        jsonResponse(false, 'Incorrect previous password.');
    }

    if (strlen($password) < 8) {
        jsonResponse(false, 'Invalid password length. It must be at least 8 characters.');
    }

    if ($password != $cpassword) {
        jsonResponse(false, 'Passwords do not match.');
    }

    if (changePassword($id, $password)) {
        jsonResponse(true, 'Password successfully updated.');
    } else {
        jsonResponse(false, 'Error updating password. Please try again.');
    }
}
?>

<br><br>
<center>
<a href="about-us.php"><p style="color:red;">About Us</p></a><br>
<p style="color:blue;">"<b>Address:</b> Level-6, Narsingdi, Dhaka 1205" <br>
<b>Phone:</b> 01881869341 <br>
<b>Email:</b> avi938@gmail.com <br><br>
At Holiday, we are passionate about providing an exceptional dining experience. <br>
Founded in 2016, Holiday has been a culinary destination for Narsingdi residents and visitors. <br>
Thank you for choosing Holiday. We look forward to serving you and creating memorable dining experiences.</p>
</center>
<br>
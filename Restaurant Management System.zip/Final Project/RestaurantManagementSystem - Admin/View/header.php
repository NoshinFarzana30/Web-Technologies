<br><br>
<center>
<h3 style="color:blue;font-family:verdana">Welcome to Holiday Restaurant</h3>
<p style="color:darkblue; font-family:verdana">Where every flavor tells a story.</p>
</center>
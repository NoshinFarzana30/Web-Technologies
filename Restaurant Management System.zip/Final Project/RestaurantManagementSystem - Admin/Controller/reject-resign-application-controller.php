<?php

    require_once('../Model/user-info-model.php'); 
    
    $id = $_GET['id'];
    
    if(rejectResign($id)) header('location:../View/manage-resign-application.php');

?>
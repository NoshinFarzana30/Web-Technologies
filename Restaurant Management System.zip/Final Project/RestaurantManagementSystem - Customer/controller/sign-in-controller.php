<?php

session_start();

    require_once('../model/user-info-model.php');

    if(isset($_POST['submit'])){

        $email = $_POST['email'];
        $password = $_POST['password'];

        $remember;
 
        if(isset($_POST['rememberMe'])){
            $remember="true";
        }
        if(!isset($_POST['rememberMe'])){
            $remember="false";
        }

        if(strlen(trim($email)) == 0 || strlen(trim($password)) == 0){

            header('location:../view/sign-in.php?err=empty');
            return;

        }

        $status = login($email, $password);

        if($status!=false){
            if($status['Role'] == "Customer" and $status['Status'] == "Active" ){

                $_SESSION['flag'] = true;
                setcookie("id", $status['UserID'], time()+99999999999, "/");
                if($remember=="true") setcookie("flag", "true", time()+999999999,"/");
                if($remember=="false") setcookie("flag","false",time()+10,"/");
                header('location:../view/customer-home.php');

            }
            else header('location:../view/sign-in.php?err=bannedUser');

        }else header('location:../view/sign-in.php?err=mismatch');
        
    }

?>
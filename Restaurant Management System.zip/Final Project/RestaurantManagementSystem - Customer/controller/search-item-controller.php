<?php

    require_once('../model/menu-model.php');
    function sanitize($data){

        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);

        return $data;

    }  

    $search = sanitize($_POST['search']); 

    if(empty($search)) {
        header('location:../view/menu.php');
        exit;
    }

    header('location:../view/menu.php?search='.$search);

?>
<?php

    require_once('database.php');

    $row;
    function customerNotification($userID, $notification, $receiver){

        $con = dbConnection();
        $sql = $con -> prepare ("insert into Notification values('', ?, ?, ?)");
        $sql -> bind_param("sss", $userID, $notification, $receiver);

        if($sql -> execute()) return true;
        else return false;
        
    }

    function deliverymanNotification($userID, $notification, $receiver){

        $con = dbConnection();
        $sql = $con -> prepare ("insert into Notification values('', ?, ?, ?)");
        $sql -> bind_param("sss", $userID, $notification, $receiver);

        if($sql -> execute()) return true;
        else return false;
        
    }

    function getCustomerNotification($id){

        $con = dbConnection();
        $sql = "select * from Notification where UserID = {$id} and Receiver = 'Customer';";
    
        $result = mysqli_query($con,$sql);
        return $result;

    }

?>
<html>
<head>
<style>
body {
  background-color:  Indigo;
}


h3 {
  color:  Indigo;
  
}

h4 {
  color:  Indigo;
  
}
</style>
</head>

<body>
<center>
<h3>
<br>
<!--<hr style = "height:2px;border-width:0;color:Lavender;background-color:Lavender">
<hr style = "height:2px;border-width:0;color:Lavender;background-color:Lavender">-->
<br>

About Us</h3>
</center>

<center>
<h4>
<b>Address:</b> Level – 9, Dhanmondi - 2, Dhaka 1205<br> 



<b>Phone:</b> 01711017345 
<br>



At Primrose, we are dedicated to crafting extraordinary dining experiences for our guests. <br>



Established in 2003, we have set out on a culinary journey to bring the finest flavors, exceptional service, and a welcoming ambiance to your table.<br><br><br>


Thank you for choosing our Restaurant. 
</h4>
</center>



</body>
</html>




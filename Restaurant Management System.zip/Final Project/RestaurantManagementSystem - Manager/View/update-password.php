<?php
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signIn');
require_once('../Model/user-info-model.php');

$id = $_COOKIE['id'];
$row = userInfo($id);

$prevpasswordMsg = $passwordMsg = $cpasswordMsg = '';

if (isset($_GET['err'])) {

    $err_msg = $_GET['err'];

    switch ($err_msg) {
        case 'prevpasswordEmpty': {
                $prevpasswordMsg = "Previous password can not be empty.";
                break;
            }
        case 'passwordEmpty': {
                $passwordMsg = "Password can not be empty.";
                break;
            }
        case 'cpasswordEmpty': {
                $cpasswordMsg = "Confirm password can not be empty.";
                break;
            }
        case 'passwordError': {
                $prevpasswordMsg = "Incorrect password.";
                break;
            }
        case 'invalid': {
                $passwordMsg = "Invalid password.";
                break;
            }
        case 'mismatch': {
                $cpasswordMsg = "Passwords do not match.";
                break;
            }
    }
}

$success_msg = '';

if (isset($_GET['success'])) {

    $s_msg = $_GET['success'];

    switch ($s_msg) {
        case 'updated': {
                $success_msg = "Password successfully updated.";
                break;
            }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Password</title>
    <link rel="stylesheet" href="CSS/style.css">
    
</head>
<script>
    function checkpassword(str) {
    console.log(str);
    if (str == "") {
        document.getElementById('message').innerHTML = "Enter your old password";
        return;
    }
    let xhttp = new XMLHttpRequest();
    xhttp.open('post', '../Controller/checkpassword-controller.php', true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send('password=' + str);
    xhttp.onload = function() {
        document.getElementById('message').innerHTML = this.responseText;
    }
}
</script>
<body>

    <form name="editinfo-form" method="post" action="../Controller/update-password-controller.php" novalidate>
        <h1>Update Password</h1>
        <br><br>
        Old Password
        <input type="password" name="prevpassword" id="prevpassword" size="43px" onkeyup="checkpassword(this.value)">
        <font id="message"></font>
        <?php if (strlen($prevpasswordMsg) > 0) { ?>
            <br><br>
            <font color="red" align="center"><?= $prevpasswordMsg ?></font>
        <?php } ?>
        <br><br>
        New Password
        <input type="password" name="password" size="43px">
        <?php if (strlen($passwordMsg) > 0) { ?>
            <br><br>
            <font color="red" align="center"><?= $passwordMsg ?></font>
        <?php } ?>
        <br><br>
        Confirm New Password
        <input type="password" name="cpassword" size="43px">
        <?php if (strlen($cpasswordMsg) > 0) { ?>
            <br><br>
            <font color="red" align="center"><?= $cpasswordMsg ?></font>
        <?php } ?>
        <?php if (strlen($success_msg) > 0) { ?>
            <br><br>
            <font color="green" align="center"><?= $success_msg ?></font>
        <?php } ?>
        <br><br>
        <button name="submit">Change Password</button>
    </form>
    <br><br><br>
    <?php require_once('footer.php') ?>
</body>

</html>
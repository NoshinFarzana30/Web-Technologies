<div id="footer"> 
<center >
  <a class="footerlink" href="#">Contact us</a> &nbsp;&nbsp; | &nbsp;&nbsp;
  <a class="footerlink" href="#">Social Media</a> &nbsp;&nbsp; | &nbsp;&nbsp;
  <a class="footerlink" href="#">Terms & Conditions</a> &nbsp;&nbsp; | &nbsp;&nbsp;
  <a class="footerlink" href="#">About Us</a> &nbsp;&nbsp; | &nbsp;&nbsp;
  <a class="footerlink" href="#">Store Location</a> <br><br><br>
  Restaurant Management System<br><br>
  <b>Address:</b> Basundhara R/A G block Road 8 <br>
  <b>Phone:</b> 01706210750 <br>
  <b>Email:</b> Arik@gmail.com<br><br>
</center>
<br>
</div>
<?php
session_start();
if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signIn');
    require_once('../Model/user-info-model.php');
    $result = getAllDeliveryPerson();
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View All Delivery Person</title>
    <link rel="stylesheet" href="CSS/style.css">
    
</head>
<script>
    function searchdeliveryperson(search){
    if(search==""){
        document.getElementById('message').innerHTML="Please Type Title";
        return;
        }
        let xhttp=new XMLHttpRequest(); 
        xhttp.open('get','../Controller/search-deliveryperson-controller.php?name='+search,true);
        xhttp.send();
        xhttp.onload=function(){
        document.getElementById('message').innerHTML=this.responseText;
    }
}
</script>
<body>
    <br><br>
    <center><h1></h1>Delivery Person List</h1>
    <br>
    <input type="text" name="search" id="search" onkeyup="searchdeliveryperson(this.value)">
        <br><br>
        <font id="message">Please Type Delivery person</font>
        </table>
        </center>

        <br><br><br>
        <br><br><br>
        <br><br><br>
        <br><br><br>
        <br><br><br>

        <?php require_once('footer.php')?>
</body>
</html>